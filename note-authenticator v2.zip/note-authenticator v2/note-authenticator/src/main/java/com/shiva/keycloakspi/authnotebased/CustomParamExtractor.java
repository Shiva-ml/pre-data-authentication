package com.shiva.keycloakspi.authnotebased;


import jakarta.ws.rs.core.MultivaluedHashMap;
import jakarta.ws.rs.core.MultivaluedMap;
import jakarta.ws.rs.core.Response;
import org.keycloak.authentication.AuthenticationFlowContext;
import org.keycloak.authentication.AuthenticationFlowError;
import org.keycloak.authentication.Authenticator;
import org.keycloak.authentication.authenticators.browser.UsernamePasswordForm;
import org.keycloak.forms.login.LoginFormsProvider;
import org.keycloak.models.*;
import org.keycloak.services.managers.AuthenticationManager;
import org.keycloak.services.messages.Messages;
import org.keycloak.sessions.AuthenticationSessionModel;
import org.jboss.logging.Logger;


public class CustomParamExtractor implements Authenticator {

    @Override
    public void authenticate(AuthenticationFlowContext context) {
        // Extract custom parameters from the authorization request
        MultivaluedMap<String, String> queryParams = context.getHttpRequest().getUri().getQueryParameters();
        String customParam1 = queryParams.getFirst("custom_param_1");
        String customParam2 = queryParams.getFirst("custom_param_2");

        // Store these values in the authentication session for later use
        if (customParam1 != null) {
            context.getAuthenticationSession().setAuthNote("custom_param_1", customParam1);
        }
        if (customParam2 != null) {
            context.getAuthenticationSession().setAuthNote("custom_param_2", customParam2);
        }

        // Mark this step as successful
        context.success();
    }

    @Override
    public void action(AuthenticationFlowContext context) {
        // No action needed
    }

    @Override
    public boolean requiresUser() {
        return false; // No user is required for this step
    }

    @Override
    public boolean configuredFor(KeycloakSession session, RealmModel realm, UserModel user) {
        return true; // This authenticator is always configured
    }

    @Override
    public void setRequiredActions(KeycloakSession session, RealmModel realm, UserModel user) {
        // No required actions
    }

    @Override
    public void close() {
        // Cleanup if necessary
    }
}
