package com.shiva.keycloakspi.authnotebased;

import jakarta.ws.rs.core.MultivaluedHashMap;
import jakarta.ws.rs.core.MultivaluedMap;
import jakarta.ws.rs.core.Response;
import org.keycloak.authentication.AuthenticationFlowContext;
import org.keycloak.authentication.AuthenticationFlowError;
import org.keycloak.authentication.Authenticator;
import org.keycloak.authentication.authenticators.browser.UsernamePasswordForm;
import org.keycloak.forms.login.LoginFormsProvider;
import org.keycloak.models.*;
import org.keycloak.services.managers.AuthenticationManager;
import org.keycloak.services.messages.Messages;
import org.keycloak.sessions.AuthenticationSessionModel;
import org.jboss.logging.Logger;

public class UsernamePasswordAuthenticator extends UsernamePasswordForm {

    // Define your predefined username here
    private static final String PREDEFINED_USERNAME = "shiva";
    private static final Logger logger = Logger.getLogger(UsernamePasswordAuthenticator.class);


    @Override
    public void authenticate(AuthenticationFlowContext context) {

        MultivaluedMap<String, String> queryParams = context.getHttpRequest().getUri().getQueryParameters();
        String PREDEFINED_USERNAME = queryParams.getFirst("myName");
        String gender = queryParams.getFirst("gender");
        context.getAuthenticationSession().setAuthNote(AuthenticationManager.FORM_USERNAME, PREDEFINED_USERNAME);

        // Customize the login form: Show predefined username or hide the username field
        LoginFormsProvider form = context.form();






        // Store these values in the authentication session for later use
        if (PREDEFINED_USERNAME != null) {
            context.getAuthenticationSession().setAuthNote("myName : ", PREDEFINED_USERNAME);
            logger.info("myName : " +PREDEFINED_USERNAME);

        }
        if (gender != null) {
            context.getAuthenticationSession().setAuthNote("gender : ", gender);
            logger.info("gender   " +gender);

        }

        // Option 1: Display the predefined username as a static field (no input)
        form.setAttribute("username", PREDEFINED_USERNAME);
        form.setAttribute("usernameHidden", true);

        Response challengeResponse = form.createLoginUsernamePassword();
        context.challenge(challengeResponse);
    }

    @Override
    protected boolean validateForm(AuthenticationFlowContext context, MultivaluedMap<String, String> formData) {
        // Override the username in the form data with the predefined one
        formData.putSingle(AuthenticationManager.FORM_USERNAME, PREDEFINED_USERNAME);

        // Continue with the regular validation process
        return validateUserAndPassword(context, formData);
    }

    @Override
    public void action(AuthenticationFlowContext context) {
        MultivaluedMap<String, String> formData = context.getHttpRequest().getDecodedFormParameters();
        // Inject predefined username before validation
        formData.putSingle(AuthenticationManager.FORM_USERNAME, PREDEFINED_USERNAME);

        // Continue with the regular action process
        super.action(context);
    }
}