package com.shiva.keycloakspi.authnotebased;

import jakarta.ws.rs.core.MultivaluedMap;
import jakarta.ws.rs.core.Response;
import org.keycloak.authentication.AuthenticationFlowContext;
import org.keycloak.authentication.authenticators.browser.UsernamePasswordForm;
import org.keycloak.forms.login.LoginFormsProvider;
import org.keycloak.services.managers.AuthenticationManager;
import org.jboss.logging.Logger;

public class UsernamePasswordAuthenticator extends UsernamePasswordForm {

    private static final Logger logger = Logger.getLogger(UsernamePasswordAuthenticator.class);

    @Override
    public void authenticate(AuthenticationFlowContext context) {
        // Extract username and other parameters from the query parameters
        MultivaluedMap<String, String> queryParams = context.getHttpRequest().getUri().getQueryParameters();
        String username = queryParams.getFirst("myName");
        String gender = queryParams.getFirst("gender");
        String HeaderValue = context.getAuthenticationSession().getAuthNote("mobile_num");
        logger.info("before validation mobile_num: " + HeaderValue);
        // Set the extracted username in the authentication session
        if (username != null) {
            context.getAuthenticationSession().setAuthNote(AuthenticationManager.FORM_USERNAME, username);
            logger.info("Username (myName): " + username);
        }

        if (gender != null) {
            context.getAuthenticationSession().setAuthNote("gender", gender);
            logger.info("Gender: " + gender);
        }

        String state = queryParams.getFirst("state");
        logger.info("provided state: " + state);
        // Customize the login form: Show the username or hide the username field
        LoginFormsProvider form = context.form();
        form.setAttribute("username", username);
        form.setAttribute("usernameHidden", true);

        Response challengeResponse = form.createLoginUsernamePassword();
        context.challenge(challengeResponse);
    }

    @Override
    protected boolean validateForm(AuthenticationFlowContext context, MultivaluedMap<String, String> formData) {
        // Use the username from the authentication session
        String username = context.getAuthenticationSession().getAuthNote(AuthenticationManager.FORM_USERNAME);
        if (username != null) {
            formData.putSingle(AuthenticationManager.FORM_USERNAME, username);
        }

        // Continue with the regular validation process
        return validateUserAndPassword(context, formData);
    }

    @Override
    public void action(AuthenticationFlowContext context) {
        MultivaluedMap<String, String> formData = context.getHttpRequest().getDecodedFormParameters();

        // Inject the username from the authentication session before validation
        String username = context.getAuthenticationSession().getAuthNote(AuthenticationManager.FORM_USERNAME);
        if (username != null) {
            formData.putSingle(AuthenticationManager.FORM_USERNAME, username);
        }

        // Continue with the regular action process
        super.action(context);
    }
}
